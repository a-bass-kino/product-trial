﻿using AltenShopService.Domain.Entities;
using AltenShopService.Presentation.Dtos;
using AutoMapper;

namespace AltenShopService.Presentation.Profiles
{
    public class ProductsProfile : Profile
    {
        public ProductsProfile()
        {
            CreateMap<Product, ProductReadDto>();

            CreateMap<ProductReadDto, Product>();

            CreateMap<ProductCreateDto, Product>();
        }
    }
}
