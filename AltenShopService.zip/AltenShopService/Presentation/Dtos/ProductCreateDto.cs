﻿using AltenShopService.Domain.Entities;
using System.ComponentModel.DataAnnotations;

namespace AltenShopService.Presentation.Dtos
{
    public class ProductCreateDto : BaseCreateDto
    {
        [Required]
        public string Code { get; set; } = string.Empty;

        [Required]
        public string Name { get; set; } = string.Empty;

        [Required]
        public string Description { get; set; } = string.Empty;

        [Required]
        public string Image { get; set; } = string.Empty;

        [Required]
        public int Price { get; set; }

        [Required]
        public Categories Category { get; set; }

        [Required]
        public double CreatedAt { get; set; }

        [Required]
        public double UpdatedAt { get; set; }
        
        [Required]
        public int ShellId { get; set; }

        [Required]
        public string InternalReference { get; set; } = string.Empty;

        [Required]
        public InventoryStatus InventoryStatus { get; set; }
        
        [Required]
        public int Rating { get; set; }
    }
}
