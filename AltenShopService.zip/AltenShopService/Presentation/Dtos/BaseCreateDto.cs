﻿using System.ComponentModel.DataAnnotations;

namespace AltenShopService.Presentation.Dtos
{
    public class BaseCreateDto
    {
        [Required]
        public int Id { get; set; }
    }
}
