﻿using AltenShopService.Domain.Entities;

namespace AltenShopService.Presentation.Dtos
{
    public class ProductReadDto : BaseReadDto
    {
        public string Code { get; set; } = string.Empty;

        public string Name { get; set; } = string.Empty;
        
        public string Description { get; set; } = string.Empty;

        public string Image { get; set; } = string.Empty;

        public int Price { get; set; }

        public Categories Category { get; set; }
       
        public double CreatedAt { get; set; }

        public double UpdatedAt { get; set; }
                
        public int ShellId { get; set; }
        
        public string InternalReference { get; set; } = string.Empty;
        
        public InventoryStatus InventoryStatus { get; set; }
        
        public int Rating { get; set; }
    }
}
