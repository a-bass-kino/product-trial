﻿using AltenShopService.Domain.Entities;
using AltenShopService.Domain.Interfaces;
using AltenShopService.Presentation.Dtos;
using AutoMapper;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AltenShopService.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        //private readonly AuthService _authService;
        private readonly IProductRepository _repository;
        private readonly IMapper _mapper;

        public ProductsController(
            //AuthService authService,
            IProductRepository repository, 
            IMapper mapper
            )
        {
            //this._authService = authService;
            this._repository = repository;
            this._mapper = mapper;
        }

        [EnableCors("_myAllowSpecificOrigins")]
        [HttpGet]
        public ActionResult<IEnumerable<ProductReadDto>> GetProducts()
        {
            IEnumerable<Product> entities = this._repository.GetAll();

            return Ok(this._mapper.Map<IEnumerable<ProductReadDto>>(entities));
        }

        [EnableCors("_myAllowSpecificOrigins")]
        [HttpGet("list")]
        public ActionResult<IEnumerable<ProductReadDto>> GetProductsById([FromQuery] List<int> ids)
        {
            List<Product> entities = new();

            foreach (int id in ids)
            {
                Product entity = this._repository.GetProductById(id);

                entities.Add(entity);
            }

            return Ok(this._mapper.Map<IEnumerable<ProductReadDto>>(entities));
        }

        [EnableCors("_myAllowSpecificOrigins")]
        [HttpGet("{id}", Name = "GetProductById")]
        public ActionResult<ProductReadDto> GetProductById(int id)
        {
            Product entity = this._repository.GetProductById(id);

            if (entity != null)
            {
                return Ok(this._mapper.Map<ProductReadDto>(entity));
            }

            return NotFound();
        }

        [EnableCors("_myAllowSpecificOrigins")]
        [HttpPut("{id}")]
        public ActionResult<ProductReadDto> UpdateProduct(int id, [FromBody] ProductCreateDto dtoUpdated)
        {
            Product existingProduct = this._repository.GetProductById(id);

            if (existingProduct == null)
            {
                return NotFound(new { message = "Product not found" });
            }

            this._mapper.Map(dtoUpdated, existingProduct);

            this._repository.UpdateProduct(existingProduct);
            
            this._repository.SaveChanges();

            ProductReadDto readDto = _mapper.Map<ProductReadDto>(existingProduct);

            return Ok(readDto);
        }
    }
}
