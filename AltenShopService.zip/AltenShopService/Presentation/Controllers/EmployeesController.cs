﻿using AltenShopService.Domain.Entities;
using AltenShopService.Domain.Interfaces;
using AltenShopService.Presentation.Dtos;
using AutoMapper;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AltenShopService.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly IEmployeeRepository _repository;
        private readonly IMapper _mapper;

        public EmployeesController(IEmployeeRepository repository, IMapper mapper)
        {
            this._repository = repository;
            this._mapper = mapper;
        }

        [EnableCors("_myAllowSpecificOrigins")]
        [HttpGet]
        public ActionResult<IEnumerable<EmployeeReadDto>> GetEmployees()
        {
            IEnumerable<Employee> entities = this._repository.GetAll();

            return Ok(this._mapper.Map<IEnumerable<EmployeeReadDto>>(entities));
        }

        [EnableCors("_myAllowSpecificOrigins")]
        [HttpGet("{id}")]
        public ActionResult<EmployeeReadDto> GetEmployeeById(int id)
        {
            Employee entity = this._repository.GetEmployeeById(id);

            if (entity != null)
            {
                return Ok(this._mapper.Map<EmployeeReadDto>(entity));
            }

            return NotFound();
        }

        [EnableCors("_myAllowSpecificOrigins")]
        [HttpPut("{id}")]
        public ActionResult<EmployeeReadDto> UpdateEmployee(int id, [FromBody] EmployeeCreateDto dtoUpdated)
        {
            Employee existingEmployee = this._repository.GetEmployeeById(id);

            if (existingEmployee == null)
            {
                return NotFound(new { message = "Employee not found" });
            }

            this._mapper.Map(dtoUpdated, existingEmployee);

            this._repository.UpdateEmployee(existingEmployee);
            
            this._repository.SaveChanges();

            EmployeeReadDto readDto = _mapper.Map<EmployeeReadDto>(existingEmployee);

            return Ok(readDto);
        }

        [EnableCors("_myAllowSpecificOrigins")]
        [HttpPost]
        public ActionResult<EmployeeReadDto> CreateEmployee(EmployeeCreateDto createDto)
        {
            Employee entity = this._mapper.Map<Employee>(createDto);

            this._repository.UpdateEmployee(entity);

            EmployeeReadDto readDto = this._mapper.Map<EmployeeReadDto>(entity);

            return CreatedAtRoute(nameof(GetEmployeeById), new { Id = entity.Id, }, readDto);
        }
    }
}
