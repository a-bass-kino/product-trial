﻿using AltenShopService.Domain.Entities;
using AltenShopService.Domain.Interfaces;
using AltenShopService.Helper;
using AltenShopService.Infrastructure.Services;
using AltenShopService.Presentation.Dtos;


using AutoMapper;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace AltenShopService.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AuthService _authService;
        private readonly IEmployeeRepository _repository;
        private readonly IMapper _mapper;

        public AuthController(
            AuthService authService,
            IEmployeeRepository repository,
            IMapper mapper
            )
        {
            this._authService = authService;
            this._repository = repository;
            this._mapper = mapper;
        }

        [HttpPost("register")]
        public ActionResult Register([FromBody] EmployeeCreateDto createDto)
        {
            if (this._authService.CanRegister(this._repository.GetAll(), createDto.Email))
            {
                return BadRequest("Username already used.");
            }

            Employee entity = this._mapper.Map<Employee>(createDto);

            entity.PasswordHash = PasswordHelper.HashPassword(createDto.Password);

            this._repository.CreateEmployee(entity);

            this._repository.SaveChanges();

            EmployeeReadDto readDto = this._mapper.Map<EmployeeReadDto>(entity);

            return Ok(new { message = "Registration succeeded" });
        }

        [EnableCors("_myAllowSpecificOrigins")]
        [HttpPost("login")]
        public ActionResult<Employee> Login([FromBody] CredentialsDto credentials)
        {
            System.Console.WriteLine(credentials);
            Employee employee = this._repository.GetEmployeeByUsername(credentials.Username);

            if (employee == null)
            {
                return Unauthorized("Wrong credentials.");
            }
            else if (!PasswordHelper.VerifyPassword(credentials.Password, employee.PasswordHash))
            {
                return Unauthorized("Wrong pwd.");
            }

            string token = this._authService.GenerateJwtToken(credentials.Username);

            return Ok(new {employee, token });

        }
    }
}
