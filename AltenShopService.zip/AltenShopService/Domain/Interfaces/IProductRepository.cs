﻿using AltenShopService.Domain.Entities;

namespace AltenShopService.Domain.Interfaces
{
    public interface IProductRepository
    {
        void CreateProduct(Product entity);

        void UpdateProduct(Product entity);

        IEnumerable<Product> GetAll();

        Product GetProductById(int id);

        bool SaveChanges();
    }
}
