﻿using AltenShopService.Domain.Entities;

namespace AltenShopService.Domain.Interfaces
{
    public interface IEmployeeRepository
    {
        void CreateEmployee(Employee entity);

        void UpdateEmployee(Employee entity);

        IEnumerable<Employee> GetAll();

        Employee GetEmployeeByUsername(string username);

        Employee GetEmployeeById(int id);

        bool SaveChanges();
    }
}
