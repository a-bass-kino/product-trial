﻿using Newtonsoft.Json;

namespace AltenShopService.Helper
{
    public class JsonFileHelper
    {
        private static readonly string JsonFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Domain", "Data", "Database");

        public static List<T> ReadFromJsonFile<T>(string filename)
        {
            string json = File.ReadAllText(Path.Combine(JsonFilePath, filename));

            return JsonConvert.DeserializeObject<List<T>>(json);
        }
    }
}
