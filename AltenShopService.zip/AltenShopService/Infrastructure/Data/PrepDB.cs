﻿
using AltenShopService.Domain.Data;
using AltenShopService.Domain.Entities;
using AltenShopService.Helper;

namespace AltenShopService.Infrastructure.Data
{
    public static class PrepDb
    {
        public static void Populate(IApplicationBuilder app)
        {
            using (var serviceScoped = app.ApplicationServices.CreateScope())
            {
                AddProducts(serviceScoped.ServiceProvider.GetService<AppDbContext>());
                AddEmployees(serviceScoped.ServiceProvider.GetService<AppDbContext>());
            }
        }

        private static void AddProducts(AppDbContext context)
        {
            if (context != null)
            {
                if (!context.Products.Any())
                {
                    List<Product> products = JsonFileHelper.ReadFromJsonFile<Product>("products.json");

                    context.Products.AddRange(products);

                    context.SaveChanges();
                }
            }
        }
        
        private static void AddEmployees(AppDbContext context)
        {
            if (context != null)
            {
                if (!context.Employees.Any())
                {
                    List<Employee> employees = JsonFileHelper.ReadFromJsonFile<Employee>("employees.json");

                    context.Employees.AddRange(employees);

                    context.SaveChanges();
                }
            }
        }
    }
}
