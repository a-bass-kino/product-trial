﻿using AltenShopService.Domain.Data;
using AltenShopService.Domain.Entities;
using AltenShopService.Domain.Interfaces;

namespace AltenShopService.Infrastructure.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly AppDbContext _context;

        public ProductRepository(AppDbContext context)
        {
            this._context = context;
        }

        public void CreateProduct(Product entity)
        {
            if (entity != null)
            {
                this._context.Products.Add(entity);
            }
            else
            {
                throw new ArgumentNullException(nameof(entity));
            }
        }

        public void UpdateProduct(Product entity)
        {
            if (entity != null)
            {
                Product current = this._context.Products.FirstOrDefault(p => p.Id == entity.Id);

                if (current?.Id == entity.Id)
                {
                    this._context.Products.Remove(current);
                    this._context.Products.Add(entity);
                }
                else
                {
                    this.CreateProduct(entity);
                }
            }
        }

        public IEnumerable<Product> GetAll()
        {
            return this._context.Products.ToList();
        }

        public Product GetProductById(int id)
        {
            return this._context.Products.FirstOrDefault(p => p.Id == id);
        }

        public bool SaveChanges()
        {
            return (this._context.SaveChanges() >= 0);
        }
    }
}
