﻿using AltenShopService.Domain.Data;
using AltenShopService.Domain.Entities;
using AltenShopService.Domain.Interfaces;

namespace AltenShopService.Infrastructure.Repositories
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly AppDbContext _context;

        public EmployeeRepository(AppDbContext context)
        {
            this._context = context;
        }

        public void CreateEmployee(Employee entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }

            this._context.Employees.Add(entity);
        }

        public void UpdateEmployee(Employee entity)
        {
            if (entity != null)
            {
                Employee currentEmployee = this._context.Employees.FirstOrDefault(p => p.Id == entity.Id);

                if (currentEmployee?.Id == entity.Id)
                {
                    this._context.Employees.Remove(currentEmployee);
                    this._context.Employees.Add(entity);
                }
                else
                {
                    this.CreateEmployee(entity);
                }
            }

            this.SaveChanges();
        }

        public IEnumerable<Employee> GetAll()
        {
            return this._context.Employees.ToList();
        }

        public Employee GetEmployeeByUsername(string username)
        {
            return this._context.Employees.FirstOrDefault(p => 0 == string.CompareOrdinal(p.Email, username) || 0 == string.CompareOrdinal(p.Username, username));
        }

        public Employee GetEmployeeById(int id)
        {
            return this._context.Employees.FirstOrDefault(p => p.Id == id);
        }

        public bool SaveChanges()
        {
            return (this._context.SaveChanges() >= 0);
        }
    }
}
