import { Component, OnInit } from '@angular/core';
import { SharedModule } from '../../shared.module';
import { Observable, tap } from 'rxjs';
import { Product } from '../../../core/models/product';
import { ProductsService } from '../../../core/models/products.service';
import { CarouselComponent } from '../../components/carousel/carousel.component';
import { CarouselItemComponent } from '../carousel-item/carousel-item.component';
import { Categories } from '../../../core/models/categories';
import { NgFor } from '@angular/common';

@Component({
  selector: 'app-home',
  imports: [
    SharedModule,
    CarouselComponent,
    CarouselItemComponent,
    NgFor
  ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent implements OnInit {
  public readonly appTitle = "ALTEN SHOP";

  product$!: Observable<Product[]>;
  products!: Product[];
  fitnessProducts!: Product[];
  accessoriesProducts!: Product[];
  clothingProducts!: Product[];
  electronicsProducts!: Product[];

  constructor(private productsService: ProductsService) {
  }

  ngOnInit(): void {
    this.product$ = this.productsService.get();
    this.productsService.get().pipe(
      tap((products) => {
        this.products = products;
        this.fitnessProducts = [...products]
          .filter(prod => prod.category === Categories.fitness)
          .slice(0, 4)

        this.accessoriesProducts = [...products]
          .filter(prod => prod.category === Categories.accessories)
          .slice(0, 4);
        
        this.clothingProducts = [...products]
          .filter(prod => prod.category === Categories.clothing)
          .slice(0, 4);
        
        this.electronicsProducts = [...products]
          .filter(prod => prod.category === Categories.electronics)
          .slice(0, 4);
      })
    ).subscribe();
  }


}
