import { Component, Input, OnInit } from '@angular/core';
import { Product } from '../../../core/models/product';
import { ProductsService } from '../../../core/models/products.service';
import { ActivatedRoute } from '@angular/router';
import { CurrencyPipe, DatePipe, NgIf, NgStyle } from '@angular/common';
import { MaterialModule } from '../../material.module';
import { CategoryTextPipe } from '../../pipes/category-text.pipe';
import { InventoryStatusColorPipe } from '../../pipes/inventory-status-color.pipe';
import { InventoryStatusTextPipe } from '../../pipes/inventory-status-text.pipe';
import { StarRatingComponent } from '../star-rating/star-rating.component';

@Component({
  selector: 'app-single-item-details',
  imports: [
    MaterialModule,
    StarRatingComponent,
    CurrencyPipe,
    DatePipe,
    CategoryTextPipe,
    InventoryStatusColorPipe,
    InventoryStatusTextPipe,
    NgIf,
    NgStyle
  ],
  templateUrl: './single-item-details.component.html',
  styleUrl: './single-item-details.component.scss'
})
export class SingleItemDetailsComponent implements OnInit {

  product!: Product;

  constructor(private service: ProductsService,
              private route: ActivatedRoute ) { }

  ngOnInit() : void {
    this.getProduct();

    console.log(this.product)
  }

  private getProduct() {
    const productId : number = this.route.snapshot.params['id'];
    
    this.service.getById(productId).subscribe(
      prod => {
        this.product = prod;

        console.log("produit : " + prod)
      }

    )

  }

}
