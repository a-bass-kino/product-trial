import { Component, Input } from '@angular/core';
import { Product } from '../../../core/models/product';

@Component({
  selector: 'app-carousel-item',
  imports: [],
  templateUrl: './carousel-item.component.html',
  styleUrl: './carousel-item.component.scss'
})
export class CarouselItemComponent {
  @Input() product!: Product;
}
