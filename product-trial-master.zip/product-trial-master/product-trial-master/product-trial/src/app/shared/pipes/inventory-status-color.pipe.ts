import { Pipe, PipeTransform } from '@angular/core';
import { InventoryStatus } from '../../core/models/inventoryStatus.enum';

@Pipe({
  name: 'inventoryStatusColor'
})
export class InventoryStatusColorPipe implements PipeTransform {

  transform(value: InventoryStatus | string): string {

    if (value === InventoryStatus.Instock || value === 'INSTOCK') {
      return 'green';
    }
    else if (value === InventoryStatus.Lowstock || value === 'LOWSTOCK') {
      return 'orange';
    }
    return 'red';
  }

}
