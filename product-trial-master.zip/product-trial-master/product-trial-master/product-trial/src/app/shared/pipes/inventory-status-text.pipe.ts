import { Pipe, PipeTransform } from '@angular/core';
import { InventoryStatus } from '../../core/models/inventoryStatus.enum';

@Pipe({
  name: 'inventoryStatusText'
})
export class InventoryStatusTextPipe implements PipeTransform {

  transform(value: InventoryStatus | string): string {

    if (value === InventoryStatus.Instock || value === 'INSTOCK') {
      return 'En stock';
    }
    else if (value === InventoryStatus.Lowstock || value === 'LOWSTOCK') {
      return 'En stock';
    }
    
    return 'Pas de stock';
  }

}
