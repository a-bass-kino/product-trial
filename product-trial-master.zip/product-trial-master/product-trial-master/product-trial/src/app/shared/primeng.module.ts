import { NgModule } from "@angular/core";
import { SplitterModule } from 'primeng/splitter';
import { DataViewModule } from 'primeng/dataview';
import { DialogModule } from 'primeng/dialog';
import { PanelMenuModule } from 'primeng/panelmenu';
import { ButtonModule } from 'primeng/button';

@NgModule({
    exports: [
        SplitterModule,
        DataViewModule,
        DialogModule,
        PanelMenuModule,
        ButtonModule
    ]
})
export class PrimengModule {}