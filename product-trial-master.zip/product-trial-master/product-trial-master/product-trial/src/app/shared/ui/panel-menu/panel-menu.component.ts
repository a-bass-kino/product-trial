import { Component } from '@angular/core';
import { MenuItem } from "primeng/api";
import { SharedModule } from '../../shared.module';

@Component({
  selector: 'app-panel-menu',
  imports: [
    SharedModule
  ],
  templateUrl: './panel-menu.component.html',
  styleUrl: './panel-menu.component.scss'
})
export class PanelMenuComponent {

    public readonly items: MenuItem[] = [
      {
        label: 'Accueil',
        icon: 'pi pi-home',
        routerLink: ['/home']
      },
      {
        label: 'Produits',
        icon: 'pi pi-barcode',
        routerLink: ['/products/list']
      }
    ]

}
