import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SharedModule } from './shared/shared.module';
import { PanelMenuComponent } from './shared/ui/panel-menu/panel-menu.component';
import { CoreModule } from './core/core.module';

@Component({
  selector: 'app-root',
  imports: [
    RouterOutlet,
    SharedModule,
    CoreModule,
    PanelMenuComponent
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = "ALTEN SHOP";
}
