export class Employee {
    constructor(
        
    ) {}
}