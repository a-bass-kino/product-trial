import { Categories } from "./categories";
import { InventoryStatus } from "./inventoryStatus.enum";

export class Product {

    constructor (
        public id : number,
        public code: string,
        public name: string,
        public description: string,
        public image: string,
        public category: Categories,
        public price: number,
        public quantity: number,
        public internalReference: string,
        public shellId: number,
        public inventoryStatus: InventoryStatus,
        public rating: number,
        public createdAt: number,
        public updatedAt: number,
    ) {}
}