export class Way {
    index: number
    path: string
    name: string

    constructor(index: number, path: string, name:string) {
        this.index = index;
        this.path = path;
        this.name = name;
    }
}