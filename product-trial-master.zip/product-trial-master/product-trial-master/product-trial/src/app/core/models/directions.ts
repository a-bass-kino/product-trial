import { Way } from "./way";

export abstract class Directions {

    constructor() {}

    public static ways : Way[] = []
    
    public static Accessories : Way = new Way(0, 'accessories',"Accessoires");
    
    public static Fitness : Way = new Way(1, 'fitness',"Fitness");
    
    public static Clothing : Way = new Way(2, 'clothing',"Vêtements");
    
    public static Electronics : Way = new Way(3, 'electronics',"Electroniques");
    
    public static Products : Way = new Way(4, 'products',"Produits");

    public static returnAllWays(): Way[] {
        if (this.ways.length == 0) {
            console.log("WAYS!!!!")
            console.log(this.Accessories)
            this.ways.push(this.Accessories)
            this.ways.push(this.Fitness)
            this.ways.push(this.Clothing)
            this.ways.push(this.Electronics)
            this.ways.push(this.Products)

            console.log(this.ways)
        }
        
        return this.ways;
    }

}