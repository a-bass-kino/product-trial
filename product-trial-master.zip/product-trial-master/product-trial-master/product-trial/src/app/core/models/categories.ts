export enum Categories {
    none = 0,

    fitness = 1,

    accessories = 2,

    clothing = 3,

    electronics = 4
}