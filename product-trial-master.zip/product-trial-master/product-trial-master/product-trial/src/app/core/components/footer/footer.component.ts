import { Component } from '@angular/core';
import { SharedModule } from '../../../shared/shared.module';
import { SubItem } from '../../models/sub-item';
import { NgFor } from '@angular/common';

@Component({
  selector: 'app-footer',
  imports: [
    SharedModule,
    NgFor
  ],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.scss'
})
export class FooterComponent {

  public readonly subItemsOne : SubItem[] = [
    new SubItem('item 1'),
    new SubItem('item 2'),
    new SubItem('item 3'),
  ];

  public readonly subItemsTwo : SubItem[] = [
    new SubItem('item 4'),
    new SubItem('item 5'),
    new SubItem('item 6'),
  ];

  public readonly subItemsThree : SubItem[] = [
    new SubItem('item 7'),
    new SubItem('item 8'),
    new SubItem('item 9'),
  ];

  public readonly subItemsFour : SubItem[] = [
    new SubItem('item 10'),
    new SubItem('item 11'),
  ];

}
