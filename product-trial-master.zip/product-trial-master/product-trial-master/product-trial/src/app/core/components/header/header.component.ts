import { Component, Input, OnInit } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { Way } from '../../models/way';
import { Directions } from '../../models/directions';

@Component({
  selector: 'app-header',
  imports: [
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent implements OnInit {

  @Input() title!: string

  public ways : Way[] = []

  constructor() {}

  ngOnInit(): void {
    this.ways = Directions.returnAllWays();
  }

}
