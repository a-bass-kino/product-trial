import { HttpClient } from '@angular/common/http';
import { Injectable, signal } from '@angular/core';
import { Employee } from '../models/employee.model';
import { Credentials } from '../interfaces/credentials.interface';
import { map, Observable, tap } from 'rxjs';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  employee : any;

  constructor(private http: HttpClient) {
    this.employee = signal<Employee | null | undefined>(undefined);
   }

   getEmployees(): Observable<Employee | null | undefined> {
    return this.http.get(`${environment.apiUrl}/employees/me`).pipe(
      tap((res: any) => {
        localStorage.setItem('token', res['token'])
        const emp = Object.assign(new Employee(), res['emp'])
        this.employee.set(emp)
      }),
      map((res: any) => {
        return this.employee();
      })
    )
   }

   login(credentials: Credentials) : Observable<Employee> {
    return this.http.post(`${environment.apiUrl}/auth/login`, credentials).pipe(
      tap((res: any) => {
        localStorage.setItem('token', res['token'])
        const emp = Object.assign(new Employee(), res['emp'])
        this.employee.set(emp)
      }),
      map((res: any) => {
        return this.employee;
      })
    )
   }

   logout() : Observable<null> {
    return this.http.get(`${environment.apiUrl}/employees/out`).pipe(
      tap((res: any) => {
        localStorage.removeItem('token');
        this.employee.set(null);
      })
    )
   }
}
