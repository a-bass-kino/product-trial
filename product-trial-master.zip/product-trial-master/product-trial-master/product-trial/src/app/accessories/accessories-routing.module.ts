import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListComponent } from './components/list/list.component';
import { SingleItemDetailsComponent } from '../shared/components/single-item-details/single-item-details.component';

const routes: Routes = [
  {
    path: 'list',
    component: ListComponent
  },
  {
    path: ':id',
    component: SingleItemDetailsComponent
  },
  { path: "**", redirectTo: "list" },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccessoriesRoutingModule { }
