import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../../../core/models/products.service';
import { Product } from '../../../core/models/product';
import { Categories } from '../../../core/models/categories';
import { AsyncPipe, NgFor, NgIf } from '@angular/common';
import { SingleItemComponent } from '../../../shared/components/single-item/single-item.component';
import { SharedModule } from '../../../shared/shared.module';

@Component({
  selector: 'app-fitness-list',
  imports: [
    SharedModule,
    SingleItemComponent,
    AsyncPipe,
    NgFor,
    NgIf
  ],
  templateUrl: './fitness-list.component.html',
  styleUrl: './fitness-list.component.scss'
})
export class FitnessListComponent implements OnInit {

  fitnessProducts!: Product[]

  constructor(private service: ProductsService) {
    console.log("cstr here")
    this.fitnessProducts = [...this.service.getProducts()].filter(prod => prod.category === Categories.fitness);
  }

  ngOnInit(): void {
    console.log("ngon here")
    this.fitnessProducts = [...this.service.getProducts()].filter(prod => prod.category === Categories.fitness);
    
  }

}
