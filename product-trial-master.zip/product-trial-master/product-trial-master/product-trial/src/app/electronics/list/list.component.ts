import { Component, OnInit } from '@angular/core';
import { SharedModule } from '../../shared/shared.module';
import { AsyncPipe, NgFor, NgIf } from '@angular/common';
import { SingleItemComponent } from '../../shared/components/single-item/single-item.component';
import { Product } from '../../core/models/product';
import { ProductsService } from '../../core/models/products.service';
import { Categories } from '../../core/models/categories';

@Component({
  selector: 'app-list',
  imports: [
    SharedModule,
    SingleItemComponent,
    AsyncPipe,
    NgFor,
    NgIf
  ],
  templateUrl: './list.component.html',
  styleUrl: './list.component.scss'
})
export class ListComponent implements OnInit {

  products!: Product[]

  constructor(private service: ProductsService) {
    console.log("cstr here")
    this.products = [...this.service.getProducts()].filter(prod => prod.category === Categories.electronics);
  }

  ngOnInit(): void {
    console.log("ngon here")
    this.products = [...this.service.getProducts()].filter(prod => prod.category === Categories.electronics);
    
  }

}
