﻿using AltenShopService.Domain.Data;
using AltenShopService.Domain.Entities;
using AltenShopService.Domain.Interfaces;

namespace AltenShopService.Infrastructure.Repositories
{
    public class ProductRepository : BaseModelRepository<Product>, IProductRepository
    {
        private readonly AppDbContext _context;

        public ProductRepository(AppDbContext context) : base(context)
        {
            this._context = context;
        }
    }
}
