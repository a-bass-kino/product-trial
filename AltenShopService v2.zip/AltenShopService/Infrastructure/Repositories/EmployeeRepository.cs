using AltenShopService.Domain.Data;
using AltenShopService.Domain.Entities;
using AltenShopService.Domain.Interfaces;

namespace AltenShopService.Infrastructure.Repositories
{
    public class EmployeeRepository: BaseModelRepository<Employee>, IEmployeeRepository
    {
        private readonly AppDbContext _context;

        public EmployeeRepository(AppDbContext context) : base(context)
        {
            this._context = context;
        }

        public Employee GetEmployeeByUsername(string username)
        {
            return this._context.Employees.FirstOrDefault(p => 0 == string.CompareOrdinal(p.Email, username) || 0 == string.CompareOrdinal(p.Username, username));
        }
    }
}