using AltenShopService.Domain.Data;
using AltenShopService.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace AltenShopService.Infrastructure.Repositories
{
    public class BaseModelRepository<T> : IBaseModelRepository<T> where T : class
    {
        private readonly AppDbContext _context;
        private readonly DbSet<T> _dbSet;

        public BaseModelRepository(AppDbContext context)
        {
            this._context = context;
            this._dbSet = this._context.Set<T>();
        }

        public void Create(T entity)
        {
            if (entity != null)
            {
                this._dbSet.Add(entity);
                this._context.SaveChanges();
            }
        }

        public void Update(T entity)
        {
            if (entity != null)
            {
                this._dbSet.Update(entity);
                this._context.SaveChanges();
            }
        }

        public void Delete(T entity)
        {
            if (entity != null)
            {
                this._dbSet.Remove(entity);
                this._context.SaveChanges();
            }
        }

        public IEnumerable<T> GetAll()
        {
            return this._dbSet.ToList();
        }

        public T GetById(int id)
        {
            return this._dbSet.Find(id);
        }

        public bool SaveChanges()
        {
            return this._context.SaveChanges() > 0;
        }
    }
}