using AutoMapper;
using AltenShopService.Domain.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;


namespace AltenShopService.Presentation.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BaseModelController<T, TCreateDto, TReadDto> : ControllerBase where T : class
    {
        private readonly IBaseModelRepository<T> _repo;
        private readonly IMapper _mapper;

        public BaseModelController(IBaseModelRepository<T> repo, IMapper mapper)
        {
            this._repo = repo;
            this._mapper = mapper;
        }

        [EnableCors("_myAllowSpecificOrigins")]
        [HttpGet]
        public ActionResult<IEnumerable<TReadDto>> GetAll()
        {
            IEnumerable<T> entities = this._repo.GetAll();

            return Ok(this._mapper.Map<IEnumerable<TReadDto>>(entities));
        }
        
        [EnableCors("_myAllowSpecificOrigins")]
        [HttpGet("{id}")]
        public ActionResult<IEnumerable<TReadDto>> GetById(int id)
        {
            T entity = this._repo.GetById(id);
            
            if (entity != null)
            {
                return Ok(this._mapper.Map<TReadDto>(entity));
            }

            return NotFound();
        }

        [Authorize]
        [EnableCors("_myAllowSpecificOrigins")]
        [HttpPost]
        public virtual ActionResult<TReadDto> Create([FromBody] TCreateDto createDto)
        {
            T entity = _mapper.Map<T>(createDto);

            this._repo.Create(entity);
            
            TReadDto readDto = this._mapper.Map<TReadDto>(entity);
            
            return Ok(readDto);
        }

        [Authorize]
        [EnableCors("_myAllowSpecificOrigins")]
        [HttpPut("{id}")]
        public ActionResult<TReadDto> Update(int id, [FromBody] TCreateDto updateDto)
        {
            T entity = this._repo.GetById(id);

            if (entity == null)
            {
                return NotFound(new { message = "Entity not found" });
            }

            entity = _mapper.Map<T>(updateDto);

            this._repo.Update(entity);

            return Ok(entity);
        }

        [Authorize]
        [EnableCors("_myAllowSpecificOrigins")]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            T entity = this._repo.GetById(id);

            if (entity == null)
            {
                return NotFound(new { message = "Entity not found" });
            }

            this._repo.Delete(entity);

            return Ok();
        }
    }
}