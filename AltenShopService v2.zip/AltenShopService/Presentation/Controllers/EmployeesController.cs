﻿using AltenShopService.Domain.Entities;
using AltenShopService.Domain.Interfaces;
using AltenShopService.Presentation.Dtos;
using AutoMapper;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AltenShopService.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : BaseModelController<Employee, EmployeeCreateDto, EmployeeReadDto>
    {
        private readonly IEmployeeRepository _repository;
        private readonly IMapper _mapper;

        public EmployeesController(IEmployeeRepository repository, IMapper mapper) : base(repository, mapper)
        {
        }
    }
}
