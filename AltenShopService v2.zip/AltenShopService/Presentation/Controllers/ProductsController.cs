﻿using AltenShopService.Domain.Entities;
using AltenShopService.Domain.Interfaces;
using AltenShopService.Presentation.Dtos;
using AutoMapper;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AltenShopService.Presentation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : BaseModelController<Product, ProductCreateDto, ProductReadDto>
    {
        private readonly IProductRepository _repository;
        private readonly IMapper _mapper;

        public ProductsController(
            IProductRepository repository, 
            IMapper mapper
            ) : base(repository, mapper)
        {
            //this._authService = authService;
            this._repository = repository;
            this._mapper = mapper;
        }

        [EnableCors("_myAllowSpecificOrigins")]
        [HttpGet("list")]
        public ActionResult<IEnumerable<ProductReadDto>> GetProductsById([FromQuery] List<int> ids)
        {
            List<Product> entities = new();

            foreach (int id in ids)
            {
                Product entity = this._repository.GetById(id);

                entities.Add(entity);
            }

            return Ok(this._mapper.Map<IEnumerable<ProductReadDto>>(entities));
        }

        // [EnableCors("_myAllowSpecificOrigins")]
        // [HttpGet("{id}", Name = "GetProductById")]
        // public ActionResult<ProductReadDto> GetProductById(int id)
        // {
        //     Product entity = this._repository.GetProductById(id);

        //     if (entity != null)
        //     {
        //         return Ok(this._mapper.Map<ProductReadDto>(entity));
        //     }

        //     return NotFound();
        // }
    }
}
