﻿namespace AltenShopService.Presentation.Dtos
{
    public class BaseReadDto
    {
        public int Id { get; set; }
    }
}
