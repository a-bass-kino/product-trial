﻿namespace AltenShopService.Presentation.Dtos
{
    public class CredentialsDto
    {
        public string Username { get; set; } = string.Empty;

        public string Password { get; set; } = string.Empty;
    }
}
