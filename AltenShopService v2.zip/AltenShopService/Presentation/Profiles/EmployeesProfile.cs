﻿using AltenShopService.Domain.Entities;
using AltenShopService.Presentation.Dtos;
using AutoMapper;

namespace AltenShopService.Presentation.Profiles
{
    public class EmployeesProfile : Profile
    {
        public EmployeesProfile()
        {
            CreateMap<Employee, EmployeeReadDto>();

            CreateMap<EmployeeReadDto, Employee>();

            CreateMap<EmployeeCreateDto, Employee>();
        }
    }
}
