﻿namespace AltenShopService.Domain.Services
{
    public class ProductService
    {
    }
}
