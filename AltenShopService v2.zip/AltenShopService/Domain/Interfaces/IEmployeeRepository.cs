using AltenShopService.Domain.Entities;


namespace AltenShopService.Domain.Interfaces
{
    public interface IEmployeeRepository : IBaseModelRepository<Employee>
    {
        Employee GetEmployeeByUsername(string username);
    }
}