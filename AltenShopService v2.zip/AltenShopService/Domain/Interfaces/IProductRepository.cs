﻿using AltenShopService.Domain.Entities;

namespace AltenShopService.Domain.Interfaces
{
    public interface IProductRepository : IBaseModelRepository<Product>
    {
    }
}
