﻿namespace AltenShopService.Domain.Entities
{
    public enum EmployeeProfile
    {
        None = 0,

        Administator = 1,

        Operator = 2,

        Supervisor = 3,
    }
}
