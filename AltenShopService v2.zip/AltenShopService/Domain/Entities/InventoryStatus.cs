namespace AltenShopService.Domain.Entities
{
    public enum InventoryStatus
    {
        None = 0,

        Instock = 1,

        Lowstock = 2,

        Outofstock = 3,
    }
}
