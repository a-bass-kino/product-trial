namespace AltenShopService.Domain.Entities
{
    public enum Categories
    {
        None = 0,

        Fitness = 1,

        Accessories = 2,

        Clothing = 3,

        Electronics = 4
    }
}
