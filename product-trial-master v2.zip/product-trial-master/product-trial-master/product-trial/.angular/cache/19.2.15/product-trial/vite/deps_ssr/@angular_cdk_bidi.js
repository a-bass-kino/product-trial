import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
} from "./chunk-JTNASOKH.js";
import "./chunk-R5VTAUEX.js";
import "./chunk-N55ZFUUE.js";
import "./chunk-SBQGIAH2.js";
import "./chunk-MKHVCWTC.js";
import "./chunk-YHCV7DAQ.js";
export {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
};
