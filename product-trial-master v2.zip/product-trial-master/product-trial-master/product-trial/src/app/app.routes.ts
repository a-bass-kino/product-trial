import { Routes } from '@angular/router';
import { Directions } from './core/models/directions';
import { HomeComponent } from './shared/components/home/home.component';
import { LoginComponent } from './auth/components/login/login.component';

export const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent,
  },
  {
    path: Directions.Accessories.path,
    loadChildren: () => import("./accessories/accessories.module").then((m) => m.AccessoriesModule) 
  },
  {
    path: Directions.Fitness.path,
    loadChildren: () => import("./fitness/fitness.module").then((m) => m.FitnessModule) 
  },
  {
    path: Directions.Clothing.path,
    loadChildren: () => import("./clothing/clothing.module").then((m) => m.ClothingModule) 
  },
  {
    path: Directions.Electronics.path,
    loadChildren: () => import("./electronics/electronics.module").then((m) => m.ElectronicsModule) 
  },
  {
    path: Directions.Products.path,
    loadChildren: () => import("./products/products.module").then((m) => m.ProductsModule) 
  },
  {
    path: 'login',
    component: LoginComponent
  },
  { path: '', redirectTo: 'home', pathMatch: 'full' },
];

