import { Component, OnInit, signal } from '@angular/core';
import { SharedModule } from '../../../shared/shared.module';
import { ProductFormComponent } from '../../ui/product-form/product-form.component';
import { Observable } from 'rxjs';
import { AsyncPipe, NgClass, NgFor, NgIf } from '@angular/common';
import { SingleItemComponent } from '../../../shared/components/single-item/single-item.component';
import { Product } from '../../../core/models/product';
import { Categories } from '../../../core/models/categories';
import { InventoryStatus } from '../../../core/models/inventoryStatus.enum';
import { ProductsService } from '../../../core/models/products.service';

const emptyProduct: Product = {
  id: 0,
  code: "",
  name: "",
  description: "",
  image: "",
  category: Categories.none,
  price: 0,
  quantity: 0,
  internalReference: "",
  shellId: 0,
  inventoryStatus: InventoryStatus.None,
  rating: 0,
  createdAt: 0,
  updatedAt: 0,
};

@Component({
  selector: 'app-product-list',
  imports: [
    SharedModule,
    ProductFormComponent,
    SingleItemComponent,
    NgFor,
    NgIf,
    NgClass,
    AsyncPipe
  ],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.scss'
})
export class ProductListComponent implements OnInit {

  public products !: Observable<Product[]>

  public isDialogVisible = false;
  public isCreation = false;
  public readonly editedProduct = signal<Product>(emptyProduct);

  constructor(private productsService: ProductsService) {}

  ngOnInit() {
    this.products = this.productsService.get();
    this.productsService.get().subscribe();
  }

  public onCreate() {
    this.isCreation = true;
    this.isDialogVisible = true;
    this.editedProduct.set(emptyProduct);
  }

  public onUpdate(product: Product) {
    this.isCreation = false;
    this.isDialogVisible = true;
    this.editedProduct.set(product);
  }

  public onDelete(product: Product) {
    this.productsService.delete(product.id).subscribe();
  }

  public onSave(product: Product) {
    if (this.isCreation) {
      this.productsService.create(product).subscribe();
    } else {
      this.productsService.update(product).subscribe();
    }
    this.closeDialog();
  }

  public onCancel() {
    this.closeDialog();
  }

  private closeDialog() {
    this.isDialogVisible = false;
  }
}
