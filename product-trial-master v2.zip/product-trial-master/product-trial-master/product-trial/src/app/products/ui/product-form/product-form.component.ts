import { Component, computed, EventEmitter, Inject, Input, input, Output } from '@angular/core';
import { SharedModule } from '../../../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SelectItem } from "primeng/api";
import { Product } from '../../../core/models/product';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { CommonModule, NgFor } from '@angular/common';

@Component({
  selector: 'app-product-form',
  imports: [
    SharedModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NgFor
  ],
  templateUrl: './product-form.component.html',
  styleUrl: './product-form.component.scss'
})
export class ProductFormComponent {
  @Input() product!: Product;

  @Output() cancel = new EventEmitter<void>();
  @Output() delete = new EventEmitter<Product>();
  @Output() save = new EventEmitter<Product>();

  public readonly categories: SelectItem[] = [
    { value: "Accessories", label: "Accessories" },
    { value: "Fitness", label: "Fitness" },
    { value: "Clothing", label: "Clothing" },
    { value: "Electronics", label: "Electronics" },
  ];

  onCancel() {
    this.cancel.emit();
  }

  onSave() {
    this.save.emit(this.product);
  }

  onDelete() {
    this.delete.emit(this.product);
  }

}
