import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccessoriesRoutingModule } from './accessories-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AccessoriesRoutingModule
  ]
})
export class AccessoriesModule { }
