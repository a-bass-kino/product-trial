import { HttpClient } from '@angular/common/http';
import { Inject, Injectable, PLATFORM_ID } from '@angular/core';
import { Employee } from '../models/employee.model';
import { Credentials } from '../interfaces/credentials.interface';
import { map, Observable, tap, BehaviorSubject } from 'rxjs';
import { environment } from '../../../environments/environment.development';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private empSub = new BehaviorSubject<Employee | null>(null);
  emp$ = this.empSub.asObservable();
  private isBrowser: boolean;

  constructor(
    private http: HttpClient, 
    @Inject(PLATFORM_ID) private platformId: object
  ) {
    this.isBrowser = isPlatformBrowser(this.platformId)

    if (this.isBrowser && localStorage.getItem('token')) {
      this.restoreSession()
    }
  }

  getEmployee(id: number): Observable<Employee> {
    return this.http.get<{ emp: Employee }>(`${environment.apiUrl}/employees/${id}`).pipe(
      map(res => Object.assign(new Employee(), res.emp)),
      tap(emp => this.empSub.next(emp))
    );
  }

  login(credentials: Credentials): Observable<Employee> {
    return this.http.post<{ token: string, employee: any }>(`${environment.apiUrl}/auth/login`, credentials).pipe(
      tap(res => {
        localStorage?.setItem('token', res.token);

        const emp = Object.assign(new Employee(), res.employee);
        
        this.empSub.next(emp);
      }),
      map(res => Object.assign(new Employee(), res.employee))
    );
  }

  restoreSession(): void {
    if (!this.isBrowser) {
      return
    }
      
    const token = localStorage?.getItem('token');
    console.log(token)
    
    if (token) {
      this.http.get<Employee>(`${environment.apiUrl}/auth/me`, {
        headers:{
          Authorization: `Bearer ${token}`
        }
      }).subscribe({
        next: (emp) =>{
          this.empSub.next(emp)
          console.log(emp)
          console.log(this.currentEmployee)
        },
        error: () => this.logout()
      });
    }
  }

  logout(): Observable<void> {
    if (!this.isBrowser) return new Observable<void>(observer => observer.complete());

    const token = localStorage.getItem('token') || '';

    return this.http.get<void>(`${environment.apiUrl}/auth/logout`, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    }).pipe(
      tap(() => {
        localStorage.removeItem('token');
        this.empSub.next(null);
      })
    );
  }

  get currentEmployee(): Employee | null {
    return this.empSub.value;
  }
}
