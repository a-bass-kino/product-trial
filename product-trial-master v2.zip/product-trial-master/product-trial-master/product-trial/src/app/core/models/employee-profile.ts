export enum EmployeeProfile {
    none = 0,

    administator = 1,

    operator = 2,

    supervisor = 3,
}
