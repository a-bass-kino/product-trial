import { Component, Input, OnInit } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { Way } from '../../models/way';
import { Directions } from '../../models/directions';
import { LoginDialogComponent } from '../../../auth/components/login-dialog/login-dialog.component';
import { SharedModule } from '../../../shared/shared.module';
import { MatDialog } from '@angular/material/dialog';
import { LoginService } from '../../services/login.service';
import { AsyncPipe, NgIf } from '@angular/common';
import { LogoutDialogComponent } from '../../../auth/components/logout-dialog/logout-dialog.component';

@Component({
  selector: 'app-header',
  imports: [
    SharedModule,
    RouterLink,
    RouterLinkActive,
    AsyncPipe,
    NgIf
  ],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent implements OnInit {

  @Input() title!: string
  emp$;

  public ways : Way[] = []

  constructor(public loginService: LoginService,
    private dialog: MatDialog) {
      this.emp$ = this.loginService.emp$
    }

  ngOnInit(): void {
    this.ways = Directions.returnAllWays();
  }

  openLoginDialog(): void {
    this.dialog.open(LoginDialogComponent, {
      width: '400px',
      panelClass: 'custom-dialog-container'
    });
  }

  openLogoutDialog(): void {
    this.dialog.open(LogoutDialogComponent, {
      width: '400px',
      panelClass: 'custom-dialog-container'
    })
  }

}
