import { Component, OnDestroy, OnInit } from '@angular/core';
import { SharedModule } from '../../../shared/shared.module';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { LoginService } from '../../../core/services/login.service';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Credentials } from '../../../core/interfaces/credentials.interface';
import { Employee } from '../../../core/models/employee.model';

@Component({
  selector: 'app-login',
  imports: [
    SharedModule,
    ReactiveFormsModule
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent implements OnInit, OnDestroy {
  loginFormGroup!: FormGroup
  invalidCredentials: boolean = false

  private loginSub : Subscription | null = null

  constructor(
    private formBuilder: FormBuilder,
    private service: LoginService,
    private router: Router
  ) {
    
  }

  ngOnInit(): void {
    this.loginFormGroup = this.formBuilder.group({
      'username': ['', [Validators.required]],
      'password': ['', [Validators.required]]
    })
  }

  ngOnDestroy(): void {
    this.loginSub?.unsubscribe();
  }

  login() : void {
    this.loginSub = this.service.login(
      this.loginFormGroup.value as Credentials
    ).subscribe({
      next: (res: Employee | null | undefined) => {
        this.navigateHome();
      },
      error: error => {
        this.invalidCredentials = true;
      }
    })
  }

  navigateHome() : void {
    this.router.navigateByUrl('home')
  }

}
