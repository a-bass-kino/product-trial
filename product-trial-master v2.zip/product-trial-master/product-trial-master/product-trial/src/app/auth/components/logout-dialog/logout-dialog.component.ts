import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { LoginService } from '../../../core/services/login.service';
import { SharedModule } from '../../../shared/shared.module';

@Component({
  selector: 'app-logout-dialog',
  imports: [
    SharedModule
  ],
  templateUrl: './logout-dialog.component.html',
  styleUrl: './logout-dialog.component.scss'
})
export class LogoutDialogComponent implements OnInit, OnDestroy {
  private logoutSub : Subscription | null = null

  constructor(
    private service: LoginService,
    private router: Router,
    private dialogRef: MatDialogRef<LogoutDialogComponent>
  ) {
  }
  
  ngOnInit(): void {
    //
  }

  ngOnDestroy(): void {
    this.logoutSub?.unsubscribe()
  }

  cancel() : void {
    this.dialogRef.close(false);
  }

  logout() : void {
    this.logoutSub = this.service.logout().subscribe({
      next: () => {
        this.dialogRef.close(true)
        
        this.router.navigate(['/']);
      }
    })
  }

}
