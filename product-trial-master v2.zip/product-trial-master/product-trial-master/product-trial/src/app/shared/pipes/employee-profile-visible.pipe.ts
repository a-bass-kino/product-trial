import { Pipe, PipeTransform } from '@angular/core';
import { EmployeeProfile } from '../../core/models/employee-profile';

@Pipe({
  name: 'employeeProfileVisible'
})
export class EmployeeProfileVisiblePipe implements PipeTransform {

  transform(value: EmployeeProfile | undefined): boolean {
    console.log("employeeProfileVisible")
    console.log(value)
    
    if (!value) {
      return false;
    }

    if (value === EmployeeProfile.administator ) {
      return true;
    }

    return false;
  }

}
