import { Pipe, PipeTransform } from '@angular/core';
import { Categories } from '../../core/models/categories';
import { Directions } from '../../core/models/directions';

@Pipe({
  name: 'categoryText'
})
export class CategoryTextPipe implements PipeTransform {

  transform(value: Categories | number): string {
    if (value === Categories.fitness || value === 1) {
      return Directions.Fitness.name;
    }
    else if (value === Categories.accessories || value === 2) {
      return Directions.Accessories.name;
    }
    else if (value === Categories.clothing || value === 3) {
      return Directions.Clothing.name;
    }
    else if (value === Categories.electronics || value === 4) {
      return Directions.Electronics.name;
    }
    
    return 'Erreur';
  }

}
