import { NgModule } from "@angular/core";
import { SplitterModule } from 'primeng/splitter';
import { DataViewModule } from 'primeng/dataview';
import { DialogModule } from 'primeng/dialog';
import { PanelMenuModule } from 'primeng/panelmenu';
import { ButtonModule } from 'primeng/button';
import { InputNumberModule } from 'primeng/inputnumber';
import { DropdownModule } from 'primeng/dropdown';

@NgModule({
    exports: [
        SplitterModule,
        DataViewModule,
        DialogModule,
        PanelMenuModule,
        ButtonModule,
        InputNumberModule,
        DropdownModule
    ]
})
export class PrimengModule {}