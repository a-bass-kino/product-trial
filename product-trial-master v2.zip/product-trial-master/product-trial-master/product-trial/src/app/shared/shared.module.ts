import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from './material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PrimengModule } from './primeng.module';
import { StarRatingComponent } from './components/star-rating/star-rating.component';
import { InventoryStatusColorPipe } from './pipes/inventory-status-color.pipe';
import { InventoryStatusTextPipe } from './pipes/inventory-status-text.pipe';
import { CategoryTextPipe } from './pipes/category-text.pipe';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MaterialModule,
    ReactiveFormsModule,
    FormsModule,
    StarRatingComponent,
    InventoryStatusColorPipe,
    InventoryStatusTextPipe,
    CategoryTextPipe
  ],
  exports: [
    MaterialModule,
    PrimengModule,
    ReactiveFormsModule,
    FormsModule,
    StarRatingComponent,
    InventoryStatusColorPipe,
    InventoryStatusTextPipe,
    CategoryTextPipe
  ]
})
export class SharedModule { }
