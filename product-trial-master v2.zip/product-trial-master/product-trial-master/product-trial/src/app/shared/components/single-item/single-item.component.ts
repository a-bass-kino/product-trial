import { Component, Input } from '@angular/core';
import { Product } from '../../../core/models/product';
import { Router } from '@angular/router';
import { MaterialModule } from '../../material.module';
import { ShortenPipe } from '../../pipes/shorten.pipe';

@Component({
  selector: 'app-single-item',
  imports: [
    MaterialModule,
    ShortenPipe
  ],
  templateUrl: './single-item.component.html',
  styleUrl: './single-item.component.scss'
})
export class SingleItemComponent {
  @Input() product!: Product;
  @Input() direction!: string;

  constructor(private router: Router) {}

  goToDetail() {
    this.router.navigateByUrl(this.direction + '/' + this.product.id)
  }

}
