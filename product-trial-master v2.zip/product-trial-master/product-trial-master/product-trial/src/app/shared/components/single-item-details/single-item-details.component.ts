import { Component, Input, OnInit } from '@angular/core';
import { Product } from '../../../core/models/product';
import { ActivatedRoute } from '@angular/router';
import { AsyncPipe, CommonModule, CurrencyPipe, DatePipe, NgIf, NgStyle } from '@angular/common';
import { MaterialModule } from '../../material.module';
import { CategoryTextPipe } from '../../pipes/category-text.pipe';
import { InventoryStatusColorPipe } from '../../pipes/inventory-status-color.pipe';
import { InventoryStatusTextPipe } from '../../pipes/inventory-status-text.pipe';
import { StarRatingComponent } from '../star-rating/star-rating.component';
import { LoginService } from '../../../core/services/login.service';
import { EmployeeProfileVisiblePipe } from '../../pipes/employee-profile-visible.pipe';
import { Employee } from '../../../core/models/employee.model';
import { Observable } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { EmployeeProfile } from '../../../core/models/employee-profile';
import { ProductFormComponent } from '../../../products/ui/product-form/product-form.component';
import { InventoryStatus } from '../../../core/models/inventoryStatus.enum';
import { Categories } from '../../../core/models/categories';
import { ProductsService } from '../../../core/models/products.service';
import { DialogModule } from 'primeng/dialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const emptyProduct: Product = {
  id: 0,
  code: "",
  name: "",
  description: "",
  image: "",
  category: Categories.none,
  price: 0,
  quantity: 0,
  internalReference: "",
  shellId: 0,
  inventoryStatus: InventoryStatus.None,
  rating: 0,
  createdAt: 0,
  updatedAt: 0,
};

@Component({
  selector: 'app-single-item-details',
  imports: [
    MaterialModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DialogModule,
    StarRatingComponent,
    CurrencyPipe,
    DatePipe,
    CategoryTextPipe,
    AsyncPipe,
    InventoryStatusColorPipe,
    InventoryStatusTextPipe,
    EmployeeProfileVisiblePipe,
    ProductFormComponent,
    NgIf,
    NgStyle
  ],
  templateUrl: './single-item-details.component.html',
  styleUrl: './single-item-details.component.scss'
})
export class SingleItemDetailsComponent implements OnInit {

  emp$ !: Observable<Employee | null>;
  product!: Product;
  displayDialog: boolean = false;
  canEdit: boolean = false

  constructor(private service: ProductsService,
              private route: ActivatedRoute,
              public loginService: LoginService) { }

  ngOnInit() : void {
    this.getProduct();

    if (this.loginService.currentEmployee?.profile === EmployeeProfile.administator) {
      this.canEdit = true;
    }
    else {
      this.canEdit = false;
    }
    
    console.log("Profil employé :", this.loginService.currentEmployee?.profile);
    console.log("Enum admin :", EmployeeProfile.administator);

  }

  showDialog() {
    this.displayDialog = true;
  }

  onSave(product: Product) {
    this.service.update(product).subscribe(() => {
      this.displayDialog = false;
      this.getProduct();
    });
  }

  onDelete(product: Product) {
    this.service.delete(product.id).subscribe(() => {
      this.displayDialog = false;
    });
  }

  onCancel() {
    this.displayDialog = false;
  }

  private getProduct() {
    const productId : number = this.route.snapshot.params['id'];
    
    this.service.getById(productId).subscribe(
      prod => {
        this.product = prod;

        console.log("produit : " + prod)
      }

    )

  }

}
