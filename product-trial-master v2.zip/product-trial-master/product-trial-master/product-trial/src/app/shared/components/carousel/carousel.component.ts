import { Component, Input, OnInit } from '@angular/core';
import { CurrencyPipe, NgIf } from '@angular/common';
import { Product } from '../../../core/models/product';

@Component({
  selector: 'app-carousel',
  imports: [
    NgIf,
    CurrencyPipe
  ],
  templateUrl: './carousel.component.html',
  styleUrl: './carousel.component.scss'
})
export class CarouselComponent implements OnInit {
  @Input() myItems!: Product[];
  @Input() canSeeSides: boolean = false;

  slideIndex: number = 0;

  constructor() {  }

  ngOnInit(): void {
    this.startCarousel(); 
  }

  startCarousel(): void {
    if(this.myItems != null) {
      setInterval(() => {
        this.slideIndex = (this.slideIndex + 1) % this.myItems.length; // Passe à l'index suivant
      }, 3000); // Change l'article toutes les 3 secondes
    }
  }
  // Fonction pour afficher l'article actuel
  getCurrentProduct(): Product {
    return this.myItems[this.slideIndex];
  } 
  
  getPreviousProduct(): Product {
    const previousIndex = (this.slideIndex - 1 + this.myItems.length) % this.myItems.length;
    return this.myItems[previousIndex];
  }
  
  getNextProduct(): Product {
    const nextIndex = (this.slideIndex + 1) % this.myItems.length;
    return this.myItems[nextIndex];
  }

}
