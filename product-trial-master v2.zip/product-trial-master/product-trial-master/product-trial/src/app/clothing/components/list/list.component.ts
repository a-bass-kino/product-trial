import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../../../core/models/products.service';
import { Product } from '../../../core/models/product';
import { Categories } from '../../../core/models/categories';
import { AsyncPipe, NgFor, NgIf } from '@angular/common';
import { SingleItemComponent } from '../../../shared/components/single-item/single-item.component';
import { SharedModule } from '../../../shared/shared.module';

@Component({
  selector: 'app-list',
  imports: [
    SharedModule,
    SingleItemComponent,
    NgFor,
    NgIf
  ],
  templateUrl: './list.component.html',
  styleUrl: './list.component.scss'
})
export class ListComponent implements OnInit {

  products!: Product[]

  constructor(private service: ProductsService) {
    this.products = [...this.service.getProducts()].filter(prod => prod.category === Categories.clothing);
  }

  ngOnInit(): void {
    this.products = [...this.service.getProducts()].filter(prod => prod.category === Categories.clothing);
    
  }

}
