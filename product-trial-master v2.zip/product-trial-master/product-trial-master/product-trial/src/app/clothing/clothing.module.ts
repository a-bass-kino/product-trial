import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClothingRoutingModule } from './clothing-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ClothingRoutingModule
  ]
})
export class ClothingModule { }
